npm install

<!-- lancer le projet -->
npm run dev